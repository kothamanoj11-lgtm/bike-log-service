"""Interactive terminal UI: menu loop, guarded input helpers, tables."""
from __future__ import annotations

import csv
import os
import sys
from datetime import date, datetime

import analytics as an
import exporter
import humanize as hu
from models import (CATEGORIES, CURRENCY, ValidationError, build_record, clean_notes,
                    parse_category, parse_cost, parse_date, parse_odometer)
from storage import Store

if os.name == "nt":
    os.system("")  # enable ANSI on Windows terminals
USE_COLOR = sys.stdout.isatty() and not os.environ.get("NO_COLOR")
COLORS = {"red": "31", "green": "32", "yellow": "33", "blue": "34", "cyan": "36", "bold": "1", "dim": "2"}
PAGE_SIZE = 10
EXPORT_DIR = "exports"


def c(text, color):
    return f"\033[{COLORS[color]}m{text}\033[0m" if USE_COLOR else str(text)


# ---------------------------------------------------------------- input helpers
class Cancelled(Exception):
    pass


def ask(prompt, parser=None, default=None, allow_blank=False):
    """Loop until `parser` accepts the input. Type 'q' to cancel the current action."""
    while True:
        try:
            raw = input(prompt)
        except EOFError:
            raise Cancelled
        raw = raw.strip()
        if raw.lower() in ("q", "quit", "cancel") and parser is not None:
            raise Cancelled
        if not raw:
            if default is not None:
                raw = default
            elif allow_blank:
                return ""
            else:
                print(c("  ! I need an answer here (or type q to cancel).", "red"))
                continue
        try:
            return parser(raw) if parser else raw
        except ValidationError as e:
            print(c(f"  ! {e}", "red"))


def confirm(prompt) -> bool:
    try:
        return input(f"{prompt} [y/N]: ").strip().lower() in ("y", "yes")
    except EOFError:
        return False


def ask_int(prompt, lo, hi):
    def p(s):
        if not s.lstrip("-").isdigit() or not lo <= int(s) <= hi:
            raise ValidationError(f"Please enter a whole number from {lo} to {hi}.")
        return int(s)
    return ask(prompt, p)


# ---------------------------------------------------------------- presentation
def banner():
    print(c("=" * 62, "cyan"))
    print(c("   BIKE SERVICE LOG  -  SmartCommunity Hack #55", "bold"))
    print(c("   Your friendly maintenance diary for two wheels", "dim"))
    print(c("=" * 62, "cyan"))


def table(recs, pause=True):
    if not recs:
        print(c("  (nothing here yet)", "dim"))
        return
    head = f"{'ID':>4}  {'Date':<10}  {'Odometer':>9}  {'Category':<17}  {'Cost':>10}  Notes"
    rule = "-" * 78
    for i, r in enumerate(recs):
        if i % PAGE_SIZE == 0:
            print(c(head, "bold")); print(rule)
        notes = r.notes if len(r.notes) <= 26 else r.notes[:23] + "..."
        print(f"{r.id:>4}  {r.date:<10}  {r.odometer:>9,}  {r.category:<17}  {r.cost:>10,.2f}  {notes}")
        last_on_page = (i + 1) % PAGE_SIZE == 0 and i + 1 < len(recs)
        if last_on_page and pause:
            print(c(f"  -- {i + 1}/{len(recs)} shown. Enter = next page, q = stop --", "dim"))
            if input().strip().lower() == "q":
                return
    print(rule)
    print(c(f"  {len(recs)} record(s)", "dim"))


def bar(value, maximum, width=28):
    n = 0 if maximum <= 0 else round(value / maximum * width)
    return "#" * n


def show_warnings(store, header=True):
    ws = an.warnings(store.records, store.settings)
    if header:
        print(c("\n-- Things worth a look --", "bold"))
    colors = {"CRITICAL": "red", "WARN": "yellow", "INFO": "blue"}
    for lvl, msg in ws:
        print(f"  {c(f'[{lvl}]', colors[lvl])} {msg}")
    if not ws:
        print(c("  All clear! Nothing needs your attention.", "green"))


def print_categories():
    for i, cat in enumerate(CATEGORIES, 1):
        print(f"   {i}. {cat}")


# ---------------------------------------------------------------- actions
def action_add(store: Store):
    print(c("\n-- Let's log a service (type q any time to back out) --", "bold"))
    try:
        d = ask(f"When was it done? [Enter = today, {date.today()}]: ", parse_date, default=date.today().isoformat())
        odo = ask("What did the odometer read (km)? ", parse_odometer)
        for msg in an.consistency_issues(store.records, d, odo):
            print(c(f"  ! {msg}", "yellow"))
            if not confirm("  Want to save it anyway?"):
                print("  No problem, I've thrown that one away."); return
        print_categories()
        cat = ask("What kind of work was it? (number or name): ", parse_category)
        cost = ask(f"How much did it cost ({CURRENCY})? ", parse_cost)
        notes = ask("Anything worth remembering? (optional): ", clean_notes, allow_blank=True)
    except Cancelled:
        print("  No worries, cancelled."); return
    rec = build_record(store.next_id(), d, odo, cat, cost, notes)
    if store.is_duplicate(rec) and not confirm(c("  ! You already have an identical entry. Add it again?", "yellow")):
        print("  No problem, I've thrown that one away."); return
    store.add(rec)
    print(c(f"  Done! Saved as entry #{rec.id}.", "green"))
    show_warnings(store, header=False)


def action_view(store: Store):
    print(c("\n-- Your service history, oldest first --", "bold"))
    table(an.sort_records(store.records))


def action_search(store: Store):
    print(c("\n-- Let's find something (press Enter to skip any filter) --", "bold"))
    try:
        kw = ask("Any word to look for? ", allow_blank=True).lower()
        print_categories()
        cat_in = ask("Only a certain kind of work? (number/name): ", allow_blank=True)
        cat = parse_category(cat_in) if cat_in else ""
        d_from = ask("From which date? ", lambda s: parse_date(s, True), allow_blank=True)
        d_to = ask("Up to which date? ", lambda s: parse_date(s, True), allow_blank=True)
    except (Cancelled, ValidationError):
        print("  No worries, cancelled."); return
    hits = [r for r in an.sort_records(store.records)
            if (not kw or kw in r.notes.lower() or kw in r.category.lower())
            and (not cat or r.category == cat)
            and (not d_from or r.date >= d_from) and (not d_to or r.date <= d_to)]
    table(hits)


def action_edit_delete(store: Store):
    print(c("\n-- Edit / delete --", "bold"))
    try:
        rid = ask("Record ID: ", lambda s: int(s) if s.isdigit() else (_ for _ in ()).throw(ValidationError("Enter a numeric ID.")))
    except Cancelled:
        return
    rec = store.get(rid)
    if not rec:
        print(c("  I can't find an entry with that ID.", "red")); return
    table([rec], pause=False)
    choice = ask("(e)dit, (d)elete, (c)ancel: ", lambda s: s.lower() if s.lower() in ("e", "d", "c") else (_ for _ in ()).throw(ValidationError("Choose e, d or c.")))
    if choice == "d" and confirm("  Really delete it? This can't be undone."):
        store.delete(rid); print(c("  Gone. It's been removed.", "green"))
    elif choice == "e":
        print("  Press Enter to keep whatever is in the brackets.")
        try:
            d = ask(f"Date [{rec.date}]: ", parse_date, default=rec.date)
            odo = ask(f"Odometer [{rec.odometer}]: ", parse_odometer, default=str(rec.odometer))
            print_categories()
            cat = ask(f"Category [{rec.category}]: ", parse_category, default=rec.category)
            cost = ask(f"Cost [{rec.cost}]: ", parse_cost, default=str(rec.cost))
            notes = ask(f"Notes [{rec.notes}]: ", clean_notes, default=rec.notes or "-")
        except Cancelled:
            print("  No worries, cancelled."); return
        for msg in an.consistency_issues(store.records, d, odo, exclude_id=rid):
            print(c(f"  ! {msg}", "yellow"))
            if not confirm("  Want to save it anyway?"):
                return
        rec.date, rec.odometer, rec.category, rec.cost = d, odo, cat, cost
        rec.notes = "" if notes == "-" else notes
        store.save(); print(c("  Updated. Looking good.", "green"))


def action_summary(store: Store):
    s = an.summarize(store.records, store.settings)
    print(c("\n== HOW IS YOUR BIKE DOING? ==", "bold"))
    if not s["count"]:
        print("  Nothing to summarise yet. Log a service first."); return
    st = s["status"]
    col = {"OK": "green", "DUE SOON": "yellow", "OVERDUE": "red"}.get(st["label"], "dim")
    print(f"  Period          : {s['first_date']}  ->  {s['last_date']}")
    print(f"  Services logged : {s['count']}")
    print(f"  Total spend     : {CURRENCY} {s['total_cost']:,.2f}   (avg {s['avg_cost']:,.2f} | median {s['median_cost']:,.2f})")
    m = s["max_cost_rec"]
    print(f"  Costliest       : {CURRENCY} {m.cost:,.2f} on {m.date} ({m.category})")
    print(f"  Distance        : {s['km_total']:,} km")
    if s["avg_km_between"] is not None:
        print(f"  Avg interval    : {s['avg_km_between']:,.0f} km / {s['avg_days_between']:.0f} days between services")
    if s["cost_per_km"]:
        print(f"  Cost per km     : {CURRENCY} {s['cost_per_km']:.2f}")
    t = s["trend"]
    pct = "" if t["pct"] is None else f" ({t['pct']:+.0f}%)"
    print(f"  Spend trend     : {t['direction']}{pct}  [last 6 mo {t['recent']:,.0f} vs prior 6 mo {t['prior']:,.0f}]")
    print(f"  Service status  : {c(st['label'], col)}  (last serviced {hu.ago(st['last'].date)}, {st['km_since']:,} km since)")

    print(c("\n  Spend by category", "bold"))
    mx = max(t_ for _, t_ in s["by_category"].values())
    for cat, (n, tot) in s["by_category"].items():
        print(f"   {cat:<17} {n:>3}x {tot:>10,.0f}  {c(bar(tot, mx), 'cyan')}")
    print(c("\n  Spend by year", "bold"))
    mx = max(t_ for _, t_ in s["by_year"].values())
    for y, (n, tot) in s["by_year"].items():
        print(f"   {y}  {n:>3}x {tot:>10,.0f}  {c(bar(tot, mx), 'blue')}")
    print(c("\n  In plain English", "bold"))
    for line in hu.insights(store.records, store.settings, store.settings.get("bike_name") or "your bike"):
        print(f"   - {line}")
    show_warnings(store)


def action_export(store: Store):
    print(c("\n-- Packaging up your reports --", "bold"))
    paths = [exporter.export_markdown(store.records, store.settings, EXPORT_DIR),
             exporter.export_text(store.records, store.settings, EXPORT_DIR),
             exporter.export_csv(store.records, EXPORT_DIR)]
    chart = exporter.export_chart(store.records, EXPORT_DIR)
    if chart:
        paths.append(chart)
    else:
        print(c("  (matplotlib not installed - chart skipped; everything else is zero-dependency)", "dim"))
    for p in paths:
        print(c(f"  Wrote {p}", "green"))


def action_import(store: Store):
    print(c("\n-- Bring in an old spreadsheet --", "bold"))
    print("  Required columns: date, odometer, category, cost  (optional: notes)")
    try:
        path = ask("Where is the CSV file? ", lambda s: s)
    except Cancelled:
        return
    if not os.path.isfile(path):
        print(c("  I can't find a file at that path. Double-check the spelling?", "red")); return
    ok, errors, dupes = 0, [], 0
    try:
        with open(path, newline="", encoding="utf-8-sig") as fh:
            reader = csv.DictReader(fh)
            reader.fieldnames = [(f or "").strip().lower() for f in (reader.fieldnames or [])]
            missing = {"date", "odometer", "category", "cost"} - set(reader.fieldnames)
            if missing:
                print(c(f"  Missing required column(s): {', '.join(sorted(missing))}", "red")); return
            for line_no, row in enumerate(reader, start=2):
                try:
                    rec = build_record(store.next_id(), row.get("date"), row.get("odometer"), row.get("category"),
                                       row.get("cost"), row.get("notes") or "")
                except ValidationError as e:
                    errors.append((line_no, str(e), row))
                    continue
                if store.is_duplicate(rec):
                    dupes += 1
                    errors.append((line_no, "Duplicate of an existing entry - skipped", row))
                    continue
                store.records.append(rec); ok += 1
    except (OSError, UnicodeDecodeError, csv.Error) as e:
        print(c(f"  Could not read file: {e}", "red")); return
    store.save()
    print(c(f"  Imported {ok} row(s); {len(errors)} rejected ({dupes} duplicates).", "green" if not errors else "yellow"))
    if errors:
        os.makedirs(EXPORT_DIR, exist_ok=True)
        log = os.path.join(EXPORT_DIR, f"import_errors_{datetime.now():%Y%m%d-%H%M%S}.log")
        with open(log, "w", encoding="utf-8") as fh:
            for line_no, msg, row in errors:
                fh.write(f"line {line_no}: {msg} | row={dict(row)}\n")
                print(c(f"   line {line_no}: {msg}", "red"))
        print(f"  Row-by-row error log: {log}")


def action_settings(store: Store):
    s = store.settings
    print(c("\n-- Settings (Enter keeps the current value) --", "bold"))
    try:
        s["bike_name"] = ask(f"What do you call your bike? [{s.get('bike_name') or 'your bike'}]: ", lambda x: x[:30],
                             default=s.get("bike_name") or "your bike")
        s["interval_days"] = ask(f"How many days between services? [{s['interval_days']}]: ",
                                 lambda x: _bounded(x, 7, 730), default=str(s["interval_days"]))
        s["interval_km"] = ask(f"How many km between services? [{s['interval_km']}]: ",
                               lambda x: _bounded(x, 100, 20000), default=str(s["interval_km"]))
        cur = ask(f"Current odometer, if you know it [{s['current_odometer'] or 'auto'}]: ", parse_odometer,
                  default=str(s["current_odometer"]) if s["current_odometer"] else None, allow_blank=True)
        s["current_odometer"] = cur or None
    except Cancelled:
        return
    store.save(); print(c("  Got it, settings saved.", "green"))


def _bounded(text, lo, hi):
    if not text.isdigit() or not lo <= int(text) <= hi:
        raise ValidationError(f"Please enter a whole number from {lo} to {hi}.")
    return int(text)


MENU = [("Log a new service", action_add), ("See my service history", action_view),
        ("Find something", action_search), ("Fix or remove an entry", action_edit_delete),
        ("How am I doing? (summary & trends)", action_summary), ("Anything I should worry about?", lambda s: show_warnings(s)),
        ("Save reports (MD / TXT / CSV / chart)", action_export), ("Import an old spreadsheet", action_import),
        ("Settings (name, service intervals)", action_settings)]


def run(data_path: str) -> None:
    store = Store(data_path)
    banner()
    for m in store.load_messages:
        print(c(f"  ! {m}", "yellow"))
    name = store.settings.get("bike_name") or "your bike"
    print(f"\n  {hu.greeting()}! Let's look after {name}.")
    print(f"  I found {hu.plural(len(store.records), 'service')} in your log ({data_path}).")
    if store.records:
        last = an.sort_records(store.records)[-1]
        print(f"  Last service: {hu.ago(last.date)} (category: {last.category}).")
    st = an.service_status(store.records, store.settings)
    if st["label"] in ("OVERDUE", "DUE SOON"):
        print(c("  Heads up: " + ("a service is overdue." if st["label"] == "OVERDUE" else "a service is coming up soon."), "red" if st["label"] == "OVERDUE" else "yellow"))
    while True:
        print(c("\nWHAT NEXT?", "bold"))
        for i, (label, _) in enumerate(MENU, 1):
            print(f"  {i}. {label}")
        print("  0. Save and say goodbye")
        try:
            choice = input("What would you like to do? ").strip()
        except (EOFError, KeyboardInterrupt):
            print(); break
        if choice == "0":
            break
        if choice.isdigit() and 1 <= int(choice) <= len(MENU):
            try:
                MENU[int(choice) - 1][1](store)
            except (KeyboardInterrupt, Cancelled):
                print("\n  Cancelled.")
        else:
            print(c("  ! Oops, pick one of the numbers above.", "red"))
    store.save()
    print(c(f"All saved. {hu.sign_off()}", "green"))
