"""Core business logic: intervals, summary metrics, status and warnings."""
from __future__ import annotations

from collections import defaultdict
from datetime import date
from statistics import mean, median

DEFAULT_SETTINGS = {"interval_days": 90, "interval_km": 1500, "current_odometer": None, "bike_name": "your bike"}
BIG_GAP_KM = 5000
BIG_GAP_DAYS = 365


def _d(rec) -> date:
    return date.fromisoformat(rec.date)


def sort_records(records):
    return sorted(records, key=lambda r: (r.date, r.odometer, r.id))


def intervals(records):
    s = sort_records(records)
    return [{"a": a, "b": b, "days": (_d(b) - _d(a)).days, "km": b.odometer - a.odometer}
            for a, b in zip(s, s[1:])]


def consistency_issues(records, date_s, odometer, exclude_id=None):
    """Check a *candidate* entry against its chronological neighbours."""
    others = sort_records([r for r in records if r.id != exclude_id])
    prev = [r for r in others if r.date <= date_s]
    nxt = [r for r in others if r.date > date_s]
    issues = []
    if prev and odometer < prev[-1].odometer:
        issues.append(f"That reading ({odometer:,} km) is lower than the {prev[-1].odometer:,} km you logged on {prev[-1].date}.")
    if nxt and odometer > nxt[0].odometer:
        issues.append(f"That reading ({odometer:,} km) is higher than the {nxt[0].odometer:,} km you logged later, on {nxt[0].date}.")
    return issues


def service_status(records, settings, today=None):
    today = today or date.today()
    if not records:
        return {"label": "NO DATA", "last": None, "days_since": None, "km_since": None, "ratio": 0.0}
    s = sort_records(records)
    last = s[-1]
    cur = settings.get("current_odometer") or max(r.odometer for r in records)
    days_since = (today - _d(last)).days
    km_since = max(cur - last.odometer, 0)
    ratio = max(days_since / settings["interval_days"], km_since / settings["interval_km"])
    label = "OVERDUE" if ratio >= 1 else "DUE SOON" if ratio >= 0.8 else "OK"
    return {"label": label, "last": last, "days_since": days_since, "km_since": km_since,
            "ratio": ratio, "current_odometer": cur}


def monthly_cost(records):
    out = defaultdict(float)
    for r in records:
        out[r.date[:7]] += r.cost
    return dict(sorted(out.items()))


def cost_trend(records, today=None):
    """Spend in the last 6 months vs. the 6 months before that."""
    today = today or date.today()
    recent = prior = 0.0
    for r in records:
        age = (today - _d(r)).days
        if 0 <= age < 183:
            recent += r.cost
        elif 183 <= age < 366:
            prior += r.cost
    pct = None if prior == 0 else (recent - prior) / prior * 100
    direction = "n/a" if pct is None else "rising" if pct > 10 else "falling" if pct < -10 else "stable"
    return {"recent": recent, "prior": prior, "pct": pct, "direction": direction}


def summarize(records, settings, today=None):
    today = today or date.today()
    if not records:
        return {"count": 0}
    s = sort_records(records)
    costs = [r.cost for r in records]
    gaps = intervals(records)
    good = [g for g in gaps if g["km"] >= 0]          # ignore rollbacks in averages
    km_total = max(s[-1].odometer - s[0].odometer, 0)
    by_cat = defaultdict(lambda: [0, 0.0])
    by_year = defaultdict(lambda: [0, 0.0])
    for r in records:
        by_cat[r.category][0] += 1
        by_cat[r.category][1] += r.cost
        by_year[r.date[:4]][0] += 1
        by_year[r.date[:4]][1] += r.cost
    return {
        "count": len(records),
        "first_date": s[0].date, "last_date": s[-1].date,
        "total_cost": sum(costs), "avg_cost": mean(costs), "median_cost": median(costs),
        "max_cost_rec": max(records, key=lambda r: r.cost),
        "km_total": km_total,
        "avg_km_between": mean(g["km"] for g in good) if good else None,
        "avg_days_between": mean(g["days"] for g in good) if good else None,
        "cost_per_km": (sum(costs) / km_total) if km_total else None,
        "by_category": {k: tuple(v) for k, v in sorted(by_cat.items(), key=lambda kv: -kv[1][1])},
        "by_year": {k: tuple(v) for k, v in sorted(by_year.items())},
        "trend": cost_trend(records, today),
        "status": service_status(records, settings, today),
    }


def warnings(records, settings, today=None):
    """Return a list of (level, message); level in CRITICAL / WARN / INFO."""
    today = today or date.today()
    out = []
    if not records:
        return [("INFO", "No services logged yet. Add the first one to get started.")]
    st = service_status(records, settings, today)
    if st["label"] == "OVERDUE":
        out.append(("CRITICAL", f"Your service is OVERDUE: it's been {st['days_since']} days and {st['km_since']:,} km since the last one "
                    f"(you aim for every {settings['interval_days']} days or {settings['interval_km']:,} km)."))
    elif st["label"] == "DUE SOON":
        out.append(("WARN", f"A service is coming up: you've used {st['ratio']*100:.0f}% of your interval "
                    f"({st['days_since']} days, {st['km_since']:,} km)."))
    for g in intervals(records):
        a, b = g["a"], g["b"]
        if g["km"] < 0:
            out.append(("CRITICAL", f"The odometer decreased from {a.odometer:,} to {b.odometer:,} km "
                        f"(entries #{a.id} and #{b.id}). Probably a typo worth fixing."))
        elif g["km"] > BIG_GAP_KM:
            out.append(("WARN", f"{g['km']:,} km passed between entries #{a.id} and #{b.id}. Did a service go unlogged?"))
        if g["days"] > BIG_GAP_DAYS:
            out.append(("WARN", f"{g['days']} days passed between entries #{a.id} and #{b.id}. Did a service go unlogged?"))
    costs = [r.cost for r in records]
    if len(costs) >= 5:
        med = median(costs)
        for r in records:
            if med > 0 and r.cost > 5 * med:
                out.append(("WARN", f"Entry #{r.id} ({r.date}) cost {r.cost:,.2f}, far above your usual {med:,.2f}. Intentional?"))
    seen = {}
    for r in records:
        key = (r.date, r.odometer, r.category)
        if key in seen:
            out.append(("WARN", f"Entries #{seen[key]} and #{r.id} look identical ({r.date}, {r.category}). Maybe a double entry?"))
        seen.setdefault(key, r.id)
    for r in records:
        if _d(r) > today:
            out.append(("WARN", f"Entry #{r.id} is dated in the future ({r.date})."))
    order = {"CRITICAL": 0, "WARN": 1, "INFO": 2}
    return sorted(out, key=lambda x: order[x[0]])
