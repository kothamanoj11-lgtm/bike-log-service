# Bike Service Log (SmartCommunity Hack #55)

A friendly, zero-dependency Python 3.10+ terminal app that talks like a person: warm prompts, plain-English insights ("In plain English"), relative dates ("6 weeks ago"), and a nickname for your bike (Settings). Tracks service dates, odometer readings and maintenance notes.

## Run
```bash
python seed_data.py --load     # optional: 32 realistic sample records (incl. edge cases)
python main.py                 # launch (data stored in data/service_log.json)
python tests/test_core.py      # unit tests
```
Optional: `pip install matplotlib` enables the PNG chart in the export menu.

## Layout
| File | Role |
|---|---|
| `models.py` | `Record` dataclass + strict validators (date, odometer, cost, category, notes) |
| `storage.py` | JSON persistence, atomic writes, corrupt/missing-file recovery |
| `analytics.py` | intervals, summary metrics, service status, trend, warnings |
| `humanize.py` | greetings, relative dates, plain-English insights |
| `exporter.py` | Markdown / TXT audit log / CSV / optional chart |
| `cli.py` | menu loop, input wrappers, paginated tables, CSV import w/ error log |
| `seed_data.py` | sample dataset (JSON + CSV) and a legacy CSV with bad rows |

## Demo script
1. Launch -> branded banner, record count, status. 2. Add entry with bad inputs (`abc`, `-5`, lower odometer) -> caught.
3. Summary (5) -> totals, averages, trend, bars, warnings. 4. Import `data/sample/legacy_import_with_errors.csv` (8) -> row-by-row errors.
5. Exit, relaunch -> data persists. 6. Export (7) -> `exports/`.
