"""Human-friendly wording: greetings, relative dates, plain-English insights."""
from __future__ import annotations

import random
from datetime import date, datetime

import analytics as an
from models import CURRENCY


def greeting(now=None) -> str:
    h = (now or datetime.now()).hour
    return "Good morning" if h < 12 else "Good afternoon" if h < 17 else "Good evening"


def ago(iso_date: str, today=None) -> str:
    days = ((today or date.today()) - date.fromisoformat(iso_date)).days
    if days < 0:
        return "in the future"
    if days == 0:
        return "today"
    if days == 1:
        return "yesterday"
    if days < 14:
        return f"{days} days ago"
    if days < 60:
        return f"{days // 7} weeks ago"
    if days < 730:
        return f"{days // 30} months ago"
    return f"{days // 365} years ago"


def plural(n, word):
    return f"{n} {word}" + ("" if n == 1 else "s")


def sign_off() -> str:
    return random.choice(["Ride safe!", "Happy riding!", "See you at the next service.",
                          "Keep those wheels turning!", "Stay safe out there!"])


def insights(records, settings, name="your bike", today=None):
    """A few plain-English sentences describing what the data says."""
    today = today or date.today()
    s = an.summarize(records, settings, today)
    if not s["count"]:
        return [f"There's nothing in the log yet. Add {name}'s first service and I'll start spotting patterns."]
    out = []
    years = max((date.fromisoformat(s["last_date"]) - date.fromisoformat(s["first_date"])).days / 365, 0.1)
    out.append(f"{name[:1].upper() + name[1:]} has been serviced {plural(s['count'], 'time')} over {years:.1f} years "
               f"and has covered about {s['km_total']:,} km.")
    if s["avg_days_between"]:
        out.append(f"On average you visit the workshop every {s['avg_days_between']:.0f} days "
                   f"(roughly every {s['avg_km_between']:,.0f} km).")
    total = s["total_cost"]
    top_cat, (n, tot) = next(iter(s["by_category"].items()))
    share = tot / total * 100 if total else 0
    out.append(f"You've spent {CURRENCY} {total:,.0f} in total. Most of it ({share:.0f}%) went on {top_cat.lower()}.")
    m = s["max_cost_rec"]
    if s["median_cost"] and m.cost > 5 * s["median_cost"]:
        out.append(f"One big job on {m.date} ({m.category.lower()}, {CURRENCY} {m.cost:,.0f}) skews the average. "
                   f"A typical visit is closer to {CURRENCY} {s['median_cost']:,.0f}.")
    t = s["trend"]
    if t["pct"] is not None and t["direction"] != "stable":
        out.append(f"Spending over the last 6 months is {t['direction']} ({t['pct']:+.0f}% vs the 6 months before).")
    st = s["status"]
    last = st["last"]
    when = ago(last.date, today)
    if st["label"] == "OVERDUE":
        out.append(f"The last service was {when}, so {name} is overdue. Time to book it in.")
    elif st["label"] == "DUE SOON":
        out.append(f"The last service was {when}. A visit is coming up soon, so you may want to book ahead.")
    else:
        left_days = max(settings["interval_days"] - st["days_since"], 0)
        out.append(f"The last service was {when}. You're good for about {left_days} more days.")
    return out
