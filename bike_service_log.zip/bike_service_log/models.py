"""Data model + strict input validation for Bike Service Log."""
from __future__ import annotations

import re
from dataclasses import asdict, dataclass
from datetime import date, datetime

CATEGORIES = [
    "Oil/Lube", "Brakes", "Tyres", "Chain/Drivetrain", "Gears",
    "Suspension", "General Tune-up", "Electrical", "Other",
]
MAX_ODOMETER = 300_000      # km, sanity ceiling for a bicycle/motorbike
MAX_COST = 100_000.0        # sanity ceiling for a single service
MAX_NOTES = 200
MIN_DATE = date(1990, 1, 1)
CURRENCY = "Rs"


class ValidationError(ValueError):
    """Raised with a human-friendly message when an input is rejected."""


@dataclass
class Record:
    id: int
    date: str          # ISO yyyy-mm-dd
    odometer: int      # km
    category: str
    cost: float
    notes: str = ""

    def to_dict(self) -> dict:
        return asdict(self)


def parse_date(text: str, allow_future: bool = False) -> str:
    text = (text or "").strip()
    for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y"):
        try:
            d = datetime.strptime(text, fmt).date()
            break
        except ValueError:
            continue
    else:
        raise ValidationError("Hmm, I couldn't read that date. Try 2026-03-15 or 15/03/2026.")
    if d < MIN_DATE:
        raise ValidationError(f"That date is before {MIN_DATE}. Could there be a typo in the year?")
    if d > date.today() and not allow_future:
        raise ValidationError("That date hasn't happened yet. Enter today's date or earlier.")
    return d.isoformat()


def parse_odometer(text: str) -> int:
    t = (text or "").strip().lower().replace(",", "")
    t = re.sub(r"\s*km$", "", t)
    if not t:
        raise ValidationError("I need an odometer reading, whatever the dashboard shows.")
    try:
        value = float(t)
    except ValueError:
        raise ValidationError("The odometer should be just a number, like 12450.")
    if value != int(value):
        raise ValidationError("Please round the odometer to a whole number of km.")
    value = int(value)
    if value < 0:
        raise ValidationError("The odometer can't go below zero. Check for a stray minus sign?")
    if value > MAX_ODOMETER:
        raise ValidationError(f"{MAX_ODOMETER:,} km is more than most bikes ever see. Did a digit sneak in?")
    return value


def parse_cost(text: str) -> float:
    t = (text or "").strip().lower().replace(",", "")
    t = re.sub(r"^(rs\.?|inr|₹|\$)\s*", "", t)
    if not t:
        raise ValidationError("How much did it cost? Enter 0 if it was free or under warranty.")
    try:
        value = float(t)
    except ValueError:
        raise ValidationError("The cost should be a number, like 450 or 450.50.")
    if value != value or value in (float("inf"), float("-inf")):
        raise ValidationError("That doesn't look like a real amount.")
    if value < 0:
        raise ValidationError("The cost can't be negative. Enter 0 if there was no charge.")
    if value > MAX_COST:
        raise ValidationError(f"{CURRENCY} {MAX_COST:,.0f}+ for one service seems like a typo. Double-check?")
    return round(value, 2)


def parse_category(text: str) -> str:
    t = (text or "").strip()
    if not t:
        raise ValidationError("Pick a category so I can file this properly.")
    if t.isdigit():
        i = int(t)
        if 1 <= i <= len(CATEGORIES):
            return CATEGORIES[i - 1]
        raise ValidationError(f"Choose a number from 1 to {len(CATEGORIES)}.")
    matches = [c for c in CATEGORIES if c.lower().startswith(t.lower())]
    if len(matches) == 1:
        return matches[0]
    if t.lower() in (c.lower() for c in CATEGORIES):
        return next(c for c in CATEGORIES if c.lower() == t.lower())
    raise ValidationError("I don't know that category. Type a number from the list or part of its name.")


def clean_notes(text: str) -> str:
    t = re.sub(r"[\x00-\x1f\x7f]", " ", text or "").strip()
    t = re.sub(r"\s+", " ", t)
    if len(t) > MAX_NOTES:
        raise ValidationError(f"Notes are a bit long ({len(t)}/{MAX_NOTES} characters). Can you trim them?")
    return t


def build_record(rec_id, date_s, odo_s, cat_s, cost_s, notes_s, allow_future=False) -> Record:
    """Validate raw strings and build a Record (used by CLI add/import/load)."""
    return Record(
        id=rec_id,
        date=parse_date(date_s, allow_future),
        odometer=parse_odometer(str(odo_s)),
        category=parse_category(cat_s),
        cost=parse_cost(str(cost_s)),
        notes=clean_notes(notes_s),
    )
