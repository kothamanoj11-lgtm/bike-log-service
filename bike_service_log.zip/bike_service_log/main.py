#!/usr/bin/env python3
"""Bike Service Log - entry point.  Usage: python main.py [--data PATH]"""
import argparse

from cli import run

if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="Bike Service Log")
    ap.add_argument("--data", default="data/service_log.json", help="path to JSON data file")
    run(ap.parse_args().data)
