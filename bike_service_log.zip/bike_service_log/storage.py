"""JSON persistence with corruption recovery and atomic writes."""
from __future__ import annotations

import json
import os
import shutil
import tempfile
from datetime import datetime

from analytics import DEFAULT_SETTINGS
from models import Record, ValidationError, build_record

SCHEMA_VERSION = 1


class Store:
    def __init__(self, path: str):
        self.path = path
        self.records: list[Record] = []
        self.settings: dict = dict(DEFAULT_SETTINGS)
        self.load_messages: list[str] = []
        self.load()

    # ---------- load / save ----------
    def load(self) -> None:
        os.makedirs(os.path.dirname(os.path.abspath(self.path)), exist_ok=True)
        try:
            with open(self.path, "r", encoding="utf-8") as fh:
                raw = json.load(fh)
        except FileNotFoundError:
            self.load_messages.append("Welcome! No log found yet, so I've started a fresh one for you.")
            self.save()
            return
        except (json.JSONDecodeError, UnicodeDecodeError):
            backup = f"{self.path}.corrupt-{datetime.now():%Y%m%d-%H%M%S}"
            shutil.copy2(self.path, backup)
            self.load_messages.append(f"Your data file looked damaged, so I saved a copy as {backup} and started fresh.")
            self.records, self.settings = [], dict(DEFAULT_SETTINGS)
            self.save()
            return

        if not isinstance(raw, dict) or not isinstance(raw.get("records"), list):
            self.load_messages.append("Unexpected file layout - ignoring contents and starting clean.")
            return
        self.settings.update({k: v for k, v in (raw.get("settings") or {}).items() if k in DEFAULT_SETTINGS})
        skipped = 0
        for item in raw["records"]:
            try:
                rec = build_record(int(item["id"]), item["date"], item["odometer"],
                                   item["category"], item["cost"], item.get("notes", ""),
                                   allow_future=True)
                self.records.append(rec)
            except (KeyError, TypeError, ValueError, ValidationError):
                skipped += 1
        if skipped:
            self.load_messages.append(f"{skipped} entr{'y' if skipped==1 else 'ies'} looked damaged, so I skipped them.")

    def save(self) -> None:
        payload = {"version": SCHEMA_VERSION, "settings": self.settings,
                   "records": [r.to_dict() for r in self.records]}
        directory = os.path.dirname(os.path.abspath(self.path))
        fd, tmp = tempfile.mkstemp(dir=directory, suffix=".tmp")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as fh:
                json.dump(payload, fh, indent=2, ensure_ascii=False)
            os.replace(tmp, self.path)          # atomic: no half-written files
        finally:
            if os.path.exists(tmp):
                os.remove(tmp)

    # ---------- CRUD ----------
    def next_id(self) -> int:
        return max((r.id for r in self.records), default=0) + 1

    def add(self, rec: Record) -> None:
        self.records.append(rec)
        self.save()

    def get(self, rec_id: int):
        return next((r for r in self.records if r.id == rec_id), None)

    def delete(self, rec_id: int) -> bool:
        before = len(self.records)
        self.records = [r for r in self.records if r.id != rec_id]
        if len(self.records) != before:
            self.save()
            return True
        return False

    def is_duplicate(self, rec: Record) -> bool:
        return any((r.date, r.odometer, r.category) == (rec.date, rec.odometer, rec.category)
                   for r in self.records)
