#!/usr/bin/env python3
"""Generate a realistic 40+ entry dataset (JSON + CSV) incl. edge cases, and a legacy CSV with bad rows.
Usage: python seed_data.py [--load]   (--load installs the sample into data/service_log.json)"""
import csv, json, os, random, sys
from datetime import date, timedelta

random.seed(55)
RANGES = {"Oil/Lube": (350, 900), "Brakes": (600, 2200), "Tyres": (1800, 5200), "Chain/Drivetrain": (700, 3000),
          "Gears": (500, 2500), "Suspension": (1500, 4500), "General Tune-up": (400, 1500),
          "Electrical": (300, 2000), "Other": (150, 1200)}
WEIGHTS = {"Oil/Lube": 6, "Brakes": 4, "Tyres": 2, "Chain/Drivetrain": 4, "Gears": 2,
           "Suspension": 1, "General Tune-up": 6, "Electrical": 1, "Other": 2}
NOTES = {"Oil/Lube": ["Engine oil + filter change", "Chain lube and clean", "Fork oil top-up"],
         "Brakes": ["Front pads replaced", "Rear brake adjusted", "Brake fluid bleed"],
         "Tyres": ["Rear tyre replaced", "Both tyres swapped", "Puncture repair + tube"],
         "Chain/Drivetrain": ["Chain and sprocket set", "Chain tension adjusted", "Cassette cleaned"],
         "Gears": ["Derailleur indexing", "Gear cable replaced"], "Suspension": ["Shock service", "Fork seals replaced"],
         "General Tune-up": ["Full tune-up", "Routine 1000 km service", "Bolts torque check, wash"],
         "Electrical": ["Headlight bulb replaced", "Battery terminal cleaned"], "Other": ["Mudguard fixed", "Stand repaired", "Bell and grips"]}

today = date.today()
d, odo, rows = today - timedelta(days=1650), 0, []
rows.append((d.isoformat(), 0, "General Tune-up", 0.0, "Pre-delivery inspection (boundary: odo 0, free)"))
while True:
    d += timedelta(days=random.randint(35, 75)); odo += random.randint(400, 1100)
    if d > today - timedelta(days=25) or len(rows) >= 40:
        break
    cat = random.choices(list(WEIGHTS), weights=WEIGHTS.values())[0]
    rows.append((d.isoformat(), odo, cat, float(round(random.randint(*RANGES[cat]), -1)), random.choice(NOTES[cat])))

rows[12] = (rows[12][0], rows[12][1], "Other", 0.0, "Warranty claim - no charge (edge: zero cost)")
rows[20] = (rows[20][0], rows[20][1], "Suspension", 18500.0, "Full fork + shock overhaul (edge: cost outlier)")
rows[27] = (rows[27][0], max(rows[27][1] - 3000, 0), rows[27][2], rows[27][3], "odometer typo? (edge: rollback)")
rows.append(rows[5])  # exact duplicate (edge)
rows.append((rows[-2][0], rows[-2][1], "Other", 120.0, "N" * 190))  # near-max-length note (boundary)
rows.sort(key=lambda r: (r[0], r[1]))

records = [dict(id=i, date=r[0], odometer=r[1], category=r[2], cost=r[3], notes=r[4]) for i, r in enumerate(rows, 1)]
os.makedirs("data/sample", exist_ok=True)
with open("data/sample/sample_dataset.json", "w", encoding="utf-8") as fh:
    json.dump({"version": 1, "settings": {"interval_days": 90, "interval_km": 1500, "current_odometer": None},
               "records": records}, fh, indent=2)
with open("data/sample/sample_dataset.csv", "w", newline="", encoding="utf-8") as fh:
    w = csv.writer(fh); w.writerow(["date", "odometer", "category", "cost", "notes"])
    w.writerows([[r["date"], r["odometer"], r["category"], r["cost"], r["notes"]] for r in records])

legacy = [["date", "odometer", "category", "cost", "notes"],
          ["2024-01-10", "5100", "Oil/Lube", "450", "good row"],
          ["31-02-2024", "5400", "Brakes", "900", "invalid calendar date"],
          ["2024-03-02", "-50", "Tyres", "2500", "negative odometer"],
          ["2024-04-11", "6100", "Gears", "abc", "non-numeric cost"],
          ["2024-05-01", "6500", "Spaceship", "300", "unknown category"],
          ["", "6800", "Other", "100", "blank date"],
          ["2024-06-20", "7200", "Chain/Drivetrain", "1,250", "good row, comma in cost"],
          ["2031-01-01", "7300", "Other", "100", "future date"]]
with open("data/sample/legacy_import_with_errors.csv", "w", newline="", encoding="utf-8") as fh:
    csv.writer(fh).writerows(legacy)

print(f"Generated {len(records)} sample records in data/sample/")
if "--load" in sys.argv:
    with open("data/service_log.json", "w", encoding="utf-8") as fh:
        json.dump({"version": 1, "settings": {"interval_days": 90, "interval_km": 1500, "current_odometer": None},
                   "records": records}, fh, indent=2)
    print("Loaded into data/service_log.json")
