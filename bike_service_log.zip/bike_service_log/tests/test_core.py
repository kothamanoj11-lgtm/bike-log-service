import os, sys, tempfile, unittest
from datetime import date, timedelta
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import analytics as an
from models import ValidationError, parse_cost, parse_date, parse_odometer, parse_category, Record
from storage import Store


class Validation(unittest.TestCase):
    def test_dates(self):
        self.assertEqual(parse_date("2024-02-29"), "2024-02-29")
        self.assertEqual(parse_date("05/03/2024"), "2024-03-05")
        for bad in ("2023-02-29", "abc", "", "1980-01-01", (date.today() + timedelta(days=2)).isoformat()):
            with self.assertRaises(ValidationError): parse_date(bad)

    def test_odometer(self):
        self.assertEqual(parse_odometer("12,450 km"), 12450)
        self.assertEqual(parse_odometer("0"), 0)
        for bad in ("-1", "12.5", "x", "", "999999"):
            with self.assertRaises(ValidationError): parse_odometer(bad)

    def test_cost_and_category(self):
        self.assertEqual(parse_cost("Rs 450.505"), 450.5)
        for bad in ("-5", "nan", "inf", "", "1e9"):
            with self.assertRaises(ValidationError): parse_cost(bad)
        self.assertEqual(parse_category("2"), "Brakes")
        self.assertEqual(parse_category("tyre"), "Tyres")
        with self.assertRaises(ValidationError): parse_category("zzz")


class Logic(unittest.TestCase):
    def recs(self):
        t = date.today()
        mk = lambda i, days, odo, cost: Record(i, (t - timedelta(days=days)).isoformat(), odo, "Other", cost, "")
        return [mk(1, 200, 1000, 100), mk(2, 120, 1800, 100), mk(3, 30, 2400, 100)]

    def test_status_and_summary(self):
        s = an.summarize(self.recs(), an.DEFAULT_SETTINGS)
        self.assertEqual(s["count"], 3); self.assertEqual(s["km_total"], 1400)
        self.assertEqual(s["status"]["label"], "OK")

    def test_overdue_and_rollback(self):
        r = self.recs(); r[2].odometer = 500
        w = an.warnings(r, {**an.DEFAULT_SETTINGS, "current_odometer": 9000})
        msgs = " ".join(m for _, m in w)
        self.assertIn("OVERDUE", msgs); self.assertIn("decreased", msgs)

    def test_consistency(self):
        self.assertTrue(an.consistency_issues(self.recs(), date.today().isoformat(), 100))


class Human(unittest.TestCase):
    def test_ago(self):
        import humanize as hu
        t = date.today()
        self.assertEqual(hu.ago(t.isoformat()), "today")
        self.assertEqual(hu.ago((t - timedelta(days=21)).isoformat()), "3 weeks ago")
        self.assertEqual(hu.ago((t - timedelta(days=400)).isoformat()), "13 months ago")

    def test_insights_empty_and_full(self):
        import humanize as hu
        self.assertIn("nothing in the log", hu.insights([], an.DEFAULT_SETTINGS)[0])
        t = date.today()
        r = [Record(1, (t - timedelta(days=100)).isoformat(), 10, "Brakes", 50.0, ""),
             Record(2, (t - timedelta(days=10)).isoformat(), 900, "Brakes", 70.0, "")]
        self.assertTrue(any("serviced 2 times" in x for x in hu.insights(r, an.DEFAULT_SETTINGS)))


class Persistence(unittest.TestCase):
    def test_roundtrip_and_corruption(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "log.json")
            s = Store(p); s.add(Record(1, "2024-01-01", 10, "Other", 5.0, "hi"))
            self.assertEqual(len(Store(p).records), 1)
            open(p, "w").write("{ not json")
            s2 = Store(p)
            self.assertEqual(s2.records, []); self.assertTrue(s2.load_messages)


if __name__ == "__main__":
    unittest.main()
