"""Export summaries as Markdown, plain-text audit log and CSV."""
from __future__ import annotations

import csv
import os
from datetime import datetime

from analytics import sort_records, summarize, warnings
import humanize as hu
from models import CURRENCY


def _stamp():
    return datetime.now().strftime("%Y%m%d-%H%M%S")


def export_csv(records, folder):
    os.makedirs(folder, exist_ok=True)
    path = os.path.join(folder, f"service_report_{_stamp()}.csv")
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["id", "date", "odometer_km", "category", "cost", "notes"])
        for r in sort_records(records):
            w.writerow([r.id, r.date, r.odometer, r.category, f"{r.cost:.2f}", r.notes])
    return path


def export_markdown(records, settings, folder):
    os.makedirs(folder, exist_ok=True)
    path = os.path.join(folder, f"service_report_{_stamp()}.md")
    s = summarize(records, settings)
    lines = ["# Bike Service Report", f"_Generated {datetime.now():%Y-%m-%d %H:%M}_", ""]
    if s["count"] == 0:
        lines.append("No records.")
    else:
        st = s["status"]
        lines += ["## In plain English", ""] + [f"- {t}" for t in hu.insights(records, settings, settings.get("bike_name") or "your bike")] + ["", "## Summary", "",
                  f"- **Services logged:** {s['count']} ({s['first_date']} to {s['last_date']})",
                  f"- **Total spend:** {CURRENCY} {s['total_cost']:,.2f}  (avg {s['avg_cost']:,.2f}, median {s['median_cost']:,.2f})",
                  f"- **Distance covered:** {s['km_total']:,} km",
                  f"- **Status:** {st['label']}",
                  f"- **Cost trend (6 mo vs prior 6):** {s['trend']['direction']}", "",
                  "## Spend by category", "", "| Category | Services | Total |", "|---|---:|---:|"]
        lines += [f"| {c} | {n} | {t:,.2f} |" for c, (n, t) in s["by_category"].items()]
        lines += ["", "## Warnings", ""]
        lines += [f"- **{lvl}** - {msg}" for lvl, msg in warnings(records, settings)] or ["- None"]
        lines += ["", "## Records", "", "| ID | Date | Odometer | Category | Cost | Notes |", "|---:|---|---:|---|---:|---|"]
        lines += [f"| {r.id} | {r.date} | {r.odometer:,} | {r.category} | {r.cost:,.2f} | {r.notes.replace('|', '/')} |"
                  for r in sort_records(records)]
    with open(path, "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines) + "\n")
    return path


def export_text(records, settings, folder):
    os.makedirs(folder, exist_ok=True)
    path = os.path.join(folder, f"audit_log_{_stamp()}.txt")
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(f"BIKE SERVICE AUDIT LOG - generated {datetime.now():%Y-%m-%d %H:%M:%S}\n{'=' * 70}\n")
        for r in sort_records(records):
            fh.write(f"[#{r.id:03d}] {r.date} | {r.odometer:>7,} km | {r.category:<17} | {r.cost:>9,.2f} | {r.notes}\n")
        fh.write(f"{'=' * 70}\nWARNINGS\n")
        ws = warnings(records, settings)
        for lvl, msg in ws:
            fh.write(f"  [{lvl}] {msg}\n")
        if not ws:
            fh.write("  none\n")
    return path


def export_chart(records, folder):
    """Optional: PNG bar chart of spend by category (needs matplotlib)."""
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        return None
    s = summarize(records, {"interval_days": 90, "interval_km": 1500, "current_odometer": None})
    if not s["count"]:
        return None
    os.makedirs(folder, exist_ok=True)
    path = os.path.join(folder, f"spend_by_category_{_stamp()}.png")
    cats = list(s["by_category"])
    plt.figure(figsize=(8, 4.5))
    plt.barh(cats[::-1], [s["by_category"][c][1] for c in cats][::-1], color="#2a7de1")
    plt.xlabel(f"Total spend ({CURRENCY})")
    plt.title("Bike service spend by category")
    plt.tight_layout()
    plt.savefig(path, dpi=130)
    plt.close()
    return path
